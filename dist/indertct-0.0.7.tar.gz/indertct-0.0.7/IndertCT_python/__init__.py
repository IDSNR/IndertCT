'''
Author: Dinis Moreira
Email: jusupaq@gmail.com
Description: A module for facilitating communication with IndertCT´s API

Dependencies: requests module
'''

__version__ = '0.0.7'

from .api_conn import Client
